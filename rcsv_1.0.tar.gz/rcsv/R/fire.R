#' Fire
#'
#' Data on fires that have occurred
#'
#' @format ## `fire`
#' A data frame with 7,240 rows and 60 columns:
#' \describe{
#'   \item{DISTANCE}{Distance covered}
#'   \item{DAMAGE}{
#' Damage caused 
#' }
#'   ...
#' }
"fire"
