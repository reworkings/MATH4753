nticket = function(N, gamma, p) {
  layout(matrix(1:2,nr=2, nc=1, byrow=TRUE))
  n = seq(N, floor(N + (N/10)), by=1)
  q = 1-p

  # Create objective function using discrete distribution
  nd<- data.frame (nums = abs(1-gamma-pbinom(N, n,p)))
  nd <- round(nd, 2)
  min <- which.min(nd$nums)
  ticket = (N-1) + min # Minus 1 since index starts at 1
  plot(nd$nums ~ n, type = "b", pch = 21, bg = "Blue") + abline(v = ticket, h=0, col = "red",        title(main =  "Objective vs n Discrete"))

  nd = ticket

  # Create objectice function using continous distribution
  nc<- data.frame (nums = abs(1-gamma-pnorm(N, n*p,sqrt(n*p*q))))
  nc <- round(nc,2)
  min <- which.min(nc$nums)
  ticket = (N-1) + min # Minus 1 since index starts at 1
  plot(nc$nums~ n, type = "l") + abline(v = ticket, h = 0, col = "blue", title(main="Objective vs n  Continuous"))

  nc = ticket

  data = list(nd, nc, N,p, gamma)
  return(data)
}

